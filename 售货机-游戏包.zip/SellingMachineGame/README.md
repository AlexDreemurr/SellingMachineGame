游玩本游戏：下载game_files中的全部文件，点击main.py

网页：https://alexdreemurr.github.io/SellingMachineGame/
