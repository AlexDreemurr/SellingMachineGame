# -*- coding: utf-8 -*-

class MachineData():
    AVAILABLE_COINS_OUTPUT = []
    ACCEPTABLE_COINS = []

    ACCEPTABLE_COINS_FOR_SAVE = []