# -*- coding: utf-8 -*-

class UserData():
    user_chosen = "开始游戏"

    page = 1
    user_coins = []
    user_saved_coins = []
    user_saved_500_coin_count = 0
    user_saved_100_coin_count = 0
    user_balance = 0
    user_saving_balance = 0
    user_bottles = []
    user_bottles_per_section = []
    user_history_bottles = []
    tip_information = ""
    game_round = 1
    game_section = 1
    task_list = []